using System.ComponentModel.DataAnnotations;
using AmlScreening.Application.Interface;
using AmlScreening.Application.Security;
using AmlScreening.Infrastructure.Data;
using AmlScreening.Portal.ViewModels;
using Microsoft.EntityFrameworkCore;
using ScreeningApi.Application.Models;
using ScreeningApi.Application.Services;

var count = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name); count++;
}
bool Valid(params string?[] names)
{
    var model = new ScreeningBatchRequest { Names = names.ToList() };
    return Validator.TryValidateObject(model, new ValidationContext(model), new List<ValidationResult>(), true);
}
Check(Valid("b"), "One-character portal lookup is accepted");
Check(Valid("Ram Bahadur", "Bishal Bista", "Ali Maychou"), "Three complete names are accepted");
Check(!Valid("", " ", null), "Blank batch is rejected");
Check(!Valid("a", "b", "c", "d"), "More than three names is rejected");
Check(!Valid(new string('a',201)), "Overlong name is rejected");
var user = new TestUser();
var options = new DbContextOptionsBuilder<AmlScreeningDbContext>()
    .UseSqlServer("Server=localhost;Database=Unused;Integrated Security=true;TrustServerCertificate=true").Options;
using var db = new AmlScreeningDbContext(options,user);
var amlSql = db.AmlRecords.ToQueryString();
Check(amlSql.Contains("fn_VisibleAmlRecordIds"), "AML query translates the shared visibility function");
Check(db.Customers.ToQueryString().Contains("OwnerUserId"), "Customer query includes owner filtering");
Check(db.Transactions.ToQueryString().Contains("OwnerUserId"), "Transaction query includes owner filtering");
Check(db.CustomerKycResults.ToQueryString().Contains("OwnerUserId"), "KYC history query includes owner filtering");
Check(db.ComplianceAlerts.ToQueryString().Contains("OwnerUserId"), "Alert query restricts parent transaction ownership");
Check(db.RiskAssessmentFactors.ToQueryString().Contains("OwnerUserId"), "Assessment factor query restricts parent ownership");
user.UserId = 12;
Check(db.Customers.ToQueryString().Contains("12"), "Query filter uses current owner, not first cached owner");
user.Admin = false; user.ViewAll = true;
Check(!db.CanAccessAllClients, "ViewAll alone does not grant system-admin access");
user.Admin = true;
Check(db.CanAccessAllClients, "Admin plus ViewAll grants system-admin access");
var request = new CustomerKycRequest { ClientReference="REF-1", Customer = new() { FullName="Example Person", Occupation="BUSINESS" } };
request.NormalizeReference();
Check(request.CustomerReference=="REF-1", "ClientReference maps to stored customer reference");
var calculator = new CustomerKycRiskCalculator();
var rules = new[] { new KycRiskRule { FactorId=1,FactorCode="OCCUPATION",WeightPercent=100,RuleId=1,RuleVersion=1,ValueCode="BUSINESS",Score=20 } };
var bands = new[] { new KycRiskBand { Id=1,BandVersion=1,MinimumScore=0,MaximumScore=100,RiskLevel="LOW",Decision="ALLOW" } };
var result = calculator.Calculate(request,new CustomerScreeningDbResult(),rules,bands);
Check(result.RiskScore==20 && result.Decision=="ALLOW", "Approved weighted score and ALLOW band are preserved");
result = calculator.Calculate(request,new CustomerScreeningDbResult { IsPrivateMatch=true,HighestMatchScore=100 },rules,bands);
Check(result.Decision=="REVIEW" && result.AmlResult.Decision=="REVIEW", "Private match cannot produce ALLOW or inconsistent decisions");
bands[0].Decision="BLOCK";
result = calculator.Calculate(request,new CustomerScreeningDbResult(),rules,bands);
Check(result.Decision=="BLOCK" && result.AmlResult.Decision=="BLOCK", "Risk-band BLOCK is preserved with no name match");
Check(result.Factors.Count==1 && result.Factors[0].RuleId==1, "Result retains rule breakdown");
Console.WriteLine($"{count} checks passed. SQL translation and calculation only; no database writes or HTTP identity tests performed.");

sealed class TestUser : ICurrentUserContext
{
 public bool IsAuthenticated => true;
 public bool Admin { get; set; }
 public bool ViewAll { get; set; }
 public bool IsAdministrator => Admin;
 public long UserId { get; set; } = 11;
 public int ClientId => 1;
 public string Username => "test-owner";
 public bool HasPermission(string permission) => permission==AppPermissions.AmlRecordsViewAll && ViewAll;
}
