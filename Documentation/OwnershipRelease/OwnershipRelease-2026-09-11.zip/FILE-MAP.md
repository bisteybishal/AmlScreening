# Exact file map

Apply the database scripts and follow README.md first. These are full-file replacements/additions, not snippets. Do not copy `verification/` into either project.

## Portal

| Action | Supplied file | Exact destination |
|---|---|---|
| Replace | [AmlScreening/Program.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Program.cs) | `C:/Projects/AmlScreening/AmlScreening/Program.cs` |
| Add | [AmlScreening/Controllers/CustomerKycHistoryController.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Controllers/CustomerKycHistoryController.cs) | `C:/Projects/AmlScreening/AmlScreening/Controllers/CustomerKycHistoryController.cs` |
| Replace | [AmlScreening/Controllers/ScreeningController.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Controllers/ScreeningController.cs) | `C:/Projects/AmlScreening/AmlScreening/Controllers/ScreeningController.cs` |
| Replace | [AmlScreening/Security/AmlRecordAuthorizationHandler.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Security/AmlRecordAuthorizationHandler.cs) | `C:/Projects/AmlScreening/AmlScreening/Security/AmlRecordAuthorizationHandler.cs` |
| Add | [AmlScreening/Services/AmlSourceSyncWorker.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Services/AmlSourceSyncWorker.cs) | `C:/Projects/AmlScreening/AmlScreening/Services/AmlSourceSyncWorker.cs` |
| Replace | [AmlScreening/Services/PortalCookieEvents.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Services/PortalCookieEvents.cs) | `C:/Projects/AmlScreening/AmlScreening/Services/PortalCookieEvents.cs` |
| Add | [AmlScreening/ViewModels/ScreeningBatchRequest.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/ViewModels/ScreeningBatchRequest.cs) | `C:/Projects/AmlScreening/AmlScreening/ViewModels/ScreeningBatchRequest.cs` |
| Add | [AmlScreening/Views/CustomerKycHistory/Details.cshtml](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Views/CustomerKycHistory/Details.cshtml) | `C:/Projects/AmlScreening/AmlScreening/Views/CustomerKycHistory/Details.cshtml` |
| Add | [AmlScreening/Views/CustomerKycHistory/Index.cshtml](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Views/CustomerKycHistory/Index.cshtml) | `C:/Projects/AmlScreening/AmlScreening/Views/CustomerKycHistory/Index.cshtml` |
| Add | [AmlScreening/Views/Screening/_SearchBatchResults.cshtml](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Views/Screening/_SearchBatchResults.cshtml) | `C:/Projects/AmlScreening/AmlScreening/Views/Screening/_SearchBatchResults.cshtml` |
| Replace | [AmlScreening/Views/Screening/_SearchResults.cshtml](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Views/Screening/_SearchResults.cshtml) | `C:/Projects/AmlScreening/AmlScreening/Views/Screening/_SearchResults.cshtml` |
| Replace | [AmlScreening/Views/Screening/Index.cshtml](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/Views/Screening/Index.cshtml) | `C:/Projects/AmlScreening/AmlScreening/Views/Screening/Index.cshtml` |
| Replace | [AmlScreening/wwwroot/js/screening.js](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening/wwwroot/js/screening.js) | `C:/Projects/AmlScreening/AmlScreening/wwwroot/js/screening.js` |
| Replace | [AmlScreening.Application/Interface/Provider/IAmlImportRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Application/Interface/Provider/IAmlImportRepository.cs) | `C:/Projects/AmlScreening/AmlScreening.Application/Interface/Provider/IAmlImportRepository.cs` |
| Replace | [AmlScreening.Application/Interface/Provider/IAmlSourceStrategy.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Application/Interface/Provider/IAmlSourceStrategy.cs) | `C:/Projects/AmlScreening/AmlScreening.Application/Interface/Provider/IAmlSourceStrategy.cs` |
| Replace | [AmlScreening.Application/Interface/Provider/IAmlSourceSyncService.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Application/Interface/Provider/IAmlSourceSyncService.cs) | `C:/Projects/AmlScreening/AmlScreening.Application/Interface/Provider/IAmlSourceSyncService.cs` |
| Replace | [AmlScreening.Application/Security/AppPermissions.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Application/Security/AppPermissions.cs) | `C:/Projects/AmlScreening/AmlScreening.Application/Security/AppPermissions.cs` |
| Replace | [AmlScreening.Application/Services/AmlSourceSyncService.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Application/Services/AmlSourceSyncService.cs) | `C:/Projects/AmlScreening/AmlScreening.Application/Services/AmlSourceSyncService.cs` |
| Replace | [AmlScreening.Domain/Common/IClientOwnedEntity.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Domain/Common/IClientOwnedEntity.cs) | `C:/Projects/AmlScreening/AmlScreening.Domain/Common/IClientOwnedEntity.cs` |
| Replace | [AmlScreening.Domain/Entities/AmlRecord.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Domain/Entities/AmlRecord.cs) | `C:/Projects/AmlScreening/AmlScreening.Domain/Entities/AmlRecord.cs` |
| Replace | [AmlScreening.Domain/Entities/Compliance/ComplianceWorkflow.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Domain/Entities/Compliance/ComplianceWorkflow.cs) | `C:/Projects/AmlScreening/AmlScreening.Domain/Entities/Compliance/ComplianceWorkflow.cs` |
| Add | [AmlScreening.Domain/Entities/Compliance/CustomerKycResult.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Domain/Entities/Compliance/CustomerKycResult.cs) | `C:/Projects/AmlScreening/AmlScreening.Domain/Entities/Compliance/CustomerKycResult.cs` |
| Replace | [AmlScreening.Infrastructure/Data/AmlScreeningDbContext.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Data/AmlScreeningDbContext.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Data/AmlScreeningDbContext.cs` |
| Add | [AmlScreening.Infrastructure/Data/VisibleAmlRecordId.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Data/VisibleAmlRecordId.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Data/VisibleAmlRecordId.cs` |
| Replace | [AmlScreening.Infrastructure/Provider/EuAmlSourceStrategy.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Provider/EuAmlSourceStrategy.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Provider/EuAmlSourceStrategy.cs` |
| Replace | [AmlScreening.Infrastructure/Provider/UnAmlSourceStrategy.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Provider/UnAmlSourceStrategy.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Provider/UnAmlSourceStrategy.cs` |
| Replace | [AmlScreening.Infrastructure/Repositories/AmlImportRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Repositories/AmlImportRepository.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Repositories/AmlImportRepository.cs` |
| Replace | [AmlScreening.Infrastructure/Repositories/AmlRecordRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Repositories/AmlRecordRepository.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Repositories/AmlRecordRepository.cs` |
| Replace | [AmlScreening.Infrastructure/Repositories/ComplianceDashboardRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Repositories/ComplianceDashboardRepository.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Repositories/ComplianceDashboardRepository.cs` |
| Replace | [AmlScreening.Infrastructure/Services/AmlWorkflowService.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Services/AmlWorkflowService.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Services/AmlWorkflowService.cs` |
| Replace | [AmlScreening.Infrastructure/Services/AuditService.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/portal/AmlScreening.Infrastructure/Services/AuditService.cs) | `C:/Projects/AmlScreening/AmlScreening.Infrastructure/Services/AuditService.cs` |

## API

| Action | Supplied file | Exact destination |
|---|---|---|
| Replace | [ScreeningApi/Program.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi/Program.cs) | `C:/Projects/ScreeningApi/ScreeningApi/Program.cs` |
| Replace | [ScreeningApi/Controllers/CustomerKycController.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi/Controllers/CustomerKycController.cs) | `C:/Projects/ScreeningApi/ScreeningApi/Controllers/CustomerKycController.cs` |
| Replace | [ScreeningApi/Controllers/CustomerScreeningController.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi/Controllers/CustomerScreeningController.cs) | `C:/Projects/ScreeningApi/ScreeningApi/Controllers/CustomerScreeningController.cs` |
| Add | [ScreeningApi/Security/ApiActorResolver.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi/Security/ApiActorResolver.cs) | `C:/Projects/ScreeningApi/ScreeningApi/Security/ApiActorResolver.cs` |
| Replace | [ScreeningApi.Application/DependencyInjection.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/DependencyInjection.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/DependencyInjection.cs` |
| Add | [ScreeningApi.Application/Interface/Repositories/IApiActorRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Interface/Repositories/IApiActorRepository.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Interface/Repositories/IApiActorRepository.cs` |
| Replace | [ScreeningApi.Application/Interface/Repositories/ICustomerKycRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Interface/Repositories/ICustomerKycRepository.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Interface/Repositories/ICustomerKycRepository.cs` |
| Add | [ScreeningApi.Application/Models/ApiActor.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Models/ApiActor.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Models/ApiActor.cs` |
| Replace | [ScreeningApi.Application/Models/CustomerKycModels.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Models/CustomerKycModels.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Models/CustomerKycModels.cs` |
| Replace | [ScreeningApi.Application/Models/CustomerScreeningDbResult.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Models/CustomerScreeningDbResult.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Models/CustomerScreeningDbResult.cs` |
| Replace | [ScreeningApi.Application/Services/CustomerKycRiskCalculator.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Services/CustomerKycRiskCalculator.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Services/CustomerKycRiskCalculator.cs` |
| Replace | [ScreeningApi.Application/Services/CustomerKycService.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Application/Services/CustomerKycService.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Application/Services/CustomerKycService.cs` |
| Replace | [ScreeningApi.Infrastructure/DependencyInjection.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Infrastructure/DependencyInjection.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Infrastructure/DependencyInjection.cs` |
| Add | [ScreeningApi.Infrastructure/Repositories/ApiActorRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Infrastructure/Repositories/ApiActorRepository.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Infrastructure/Repositories/ApiActorRepository.cs` |
| Replace | [ScreeningApi.Infrastructure/Repositories/CustomerKycRepository.cs](C:/Projects/AmlScreening/Documentation/OwnershipRelease/api/ScreeningApi.Infrastructure/Repositories/CustomerKycRepository.cs) | `C:/Projects/ScreeningApi/ScreeningApi.Infrastructure/Repositories/CustomerKycRepository.cs` |

## Remove or retire

- Do not delete database business rows or existing accounts.
- The replacement repository removes the ordinary ViewClient bypass. Do not separately remove the permission catalogue row without checking other screens.
- `/api/customer-screening` returns authenticated 410; migrate callers to `/api/customer-kyc`. Old service/model files may remain unused; no deletion is required to build.
- Replace old source-sync interface/provider implementations together; cancellation signatures changed consistently.
- Old `ScreeningPageViewModel.cs` can stay unused; the new batch request is used by the replacement controller.
- Keep existing approved risk settings and maker-checker code.
- Keep UsersController/AccountController/current user records. Do not apply earlier organization-dropdown instructions for user privacy.
