# Verification record — 11 September 2026

## Completed

- Read the current portal/API code and the pasted review. Preserved the user's existing dirty worktree.
- Read-only local SQL checks confirmed `AMLScreening`, 1,011 AML records, no `Customers.OwnerUserId`, and no `CustomerKycResults` table.
- Verified the existing unique index names used in the migration: `UX_Customers_ClientReference`, `UX_AmlRecords_Client_Source_Reference`, `UX_AmlTransactions_ClientReference`.
- Verified the permission columns used by the scripts: PermissionId, PermissionName, Description, IsActive; effective role/override logic matches the existing repository.
- Built isolated portal and API copies with .NET SDK 10.0.300: zero compile errors, including Razor views.
- Ran 19 console checks: 1–3-name validation, generated EF visibility SQL, customer/transaction/history/alert/factor ownership filters, per-context owner changes, system-admin privilege conjunction, clientReference normalization, approved weighted score, and consistent REVIEW/BLOCK decisions.
- Parsed all eight SQL scripts with Microsoft SQL ScriptDom: no syntax errors.
- Checked screening.js with `node --check`: no syntax errors.

## Limits of those checks

- SQL syntax parsing is not execution: no migration was applied to your database, and no SQL functions/procedures were integration-tested against a migrated database.
- EF SQL-generation assertions check that restrictions are present; they do not replace A/B/admin HTTP tests against real test data.
- No valid OAuth tokens, provider availability, PEP/CIB feeds, production startup, vulnerability audit, concurrency/failure injection, browser visual rendering or load tests were verified.
- No claim of legal/regulatory adequacy or complete sanctions identity matching is made. Existing exact-name/alias coverage and risk formulas require the normal business approval.

## Build warnings

- NuGet vulnerability information could not be fetched from nuget.org in the restricted environment (NU1900). Dependencies were available for compilation. Run your deployment vulnerability audit with network access.
- The user's existing portal Program.cs has an unused `ValidateHostedConfiguration` local function (CS8321). This package does not claim that function ran or validated deployment settings.

## Unchanged live state

Source replacements, SQL and instructions exist only under Documentation/OwnershipRelease. Verification copies/build outputs also live there. No database records, active source files, permissions, API application mappings or running services were changed by this task.

## Required remaining acceptance

Follow README.md and database/04-verify-readonly.sql on a restored test database. Confirm source grants, API issuer/subject mapping, original request snapshots, same-owner API/portal history, B/C denial by direct ID, admin inspection, import/private-reference collision, and atomic rollback. Only then switch production traffic to the matching upgraded database and binaries.
